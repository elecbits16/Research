<?php

$con=mysqli_connect ("localhost","root","","flybuy");
if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}



?>