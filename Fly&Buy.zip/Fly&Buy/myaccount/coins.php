<!DOCTYPE html>
<html>
<head>
  <title></title>

  <style type="text/css">
  .btn{
    font-size: 14px;
  }
</style>

</head>




<body>

<div  class="col-lg-12 ">


<br>

  <div class="container">








<br>







<?php

$c_email =  $_SESSION['email'];

 $name_query="SELECT * FROM accounts WHERE email='$c_email' ";

      $run_name_query = mysqli_query($con , $name_query);
      
    $row_name_pro = mysqli_fetch_array($run_name_query);
         $customer_name = $row_name_pro['name'];
        $contact = $row_name_pro['contact'];
        $coins = $row_name_pro['coins'];






?>


<div class="card" >
  <div class="card-header">
   Hi  <?php echo "$customer_name ($contact), you have $coins coins"; ?>
  </div>
  










</div>
<br>





</div>


    </div>





</body>
</html>