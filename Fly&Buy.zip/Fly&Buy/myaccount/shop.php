<!DOCTYPE html>
<html>
<head>
  <title></title>

  <style type="text/css">
  .btn{
    font-size: 14px;
  }
</style>

</head>




<body>

<div  class="col-lg-12 ">


<br>

  <div class="container">








<br>







<?php

$c_email =  $_SESSION['email'];

if (isset($_GET['shop_cat'])) {
  
  $shop_cat = $_GET['shop_cat'];


 
 $sell_query="SELECT * FROM seller where category = '$shop_cat' ";

      $run_sell_query = mysqli_query($con , $sell_query);
      
  while($row_sell_pro = mysqli_fetch_array($run_sell_query))
  {
         $shop_add = $row_sell_pro['address'];
         $shop_name = $row_sell_pro['shop_name'];





?>


<div class="card" >
  <div class="card-header">
     <?php echo $shop_name; ?><br>
     <?php echo $shop_add; ?>

       <button class="btn btn-primary" type="button" >
  Open Cam
  </button>
  </div>
  










</div>

<?php

}

}

?>
<br>





</div>


    </div>





</body>
</html>