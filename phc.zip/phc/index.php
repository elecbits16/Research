<!DOCTYPE html>
<html>
<head>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
	<title>Red Plus Revolution</title>
</head>
<body>

<br>
<br>

<div class="container">
	<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-3">Red Plus Revolution</h1>
   
  </div>
</div>

	<p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Add Household
  </a>
  
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
  


<p>
  <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Individual</a>
  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Child</button>
  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#multiCollapseExample3" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">Pregnant Women</button>
</p>
<div class="row">
	  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample1">
      <div class="card card-body">

      	<form>


    <div class="form-group row">
  
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Name">
    </div>
  </div>
  <div class="form-group row">
  
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Age">
    </div>
  </div>
  <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Weight">
    </div>
  </div>
 <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Height">
    </div>
  </div>



  <fieldset class="form-group">
    <div class="row">
     
      <div class="col-sm-10">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          <label class="form-check-label" for="gridRadios1">
          Male
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
           Female
          </label>
        </div>
    
      </div>
    </div>
  </fieldset>





<fieldset class="form-group">
	 <label for="exampleInputEmail1" class="col-sm-5" style="font-size: 14px;">Any H/O</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">TB</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Diabetes</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Hypertension</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Leprosy</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Medicine H/O</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to ANM</button>
    </div>
  </div>
    <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to PHC (MO)</button>
    </div>
  </div>
</form>
       

      </div>
    </div>
  </div>




  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample2">
      <div class="card card-body">
     	<form>
  <div class="form-group row">
  
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Name">
    </div>
  </div>
  <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Age">
    </div>
  </div>
 <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Height">
    </div>
  </div>
 <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Weight">
    </div>
  </div>



  <fieldset class="form-group">
    <div class="row">
     
      <div class="col-sm-10">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          <label class="form-check-label" for="gridRadios1">
          Male
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
           Female
          </label>
        </div>
    
      </div>
    </div>
  </fieldset>





<fieldset class="form-group">
	 <label for="exampleInputEmail1" class="col-sm-5" style="font-size: 14px;">Immunization Status</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Formal Education</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1" style="font-size: 12px;">Private</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2" style="font-size: 12px;">Anganwadi</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Supplements</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Any Disease</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>








  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to ANM</button>
    </div>
  </div>
    <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to PHC (MO)</button>
    </div>
  </div>
</form>


      </div>
    </div>
  </div>



  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample3">
      <div class="card card-body">
      

	<form>
  <div class="form-group row">
  
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Name">
    </div>
  </div>
  <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Age">
    </div>
  </div>
 <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Height">
    </div>
  </div>
 <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Weight">
    </div>
  </div>








<fieldset class="form-group">
	 <label for="exampleInputEmail1" class="col-sm-5" style="font-size: 14px;">Antenatal Clinic Attendance</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>



<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Usg Done</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1" style="font-size: 12px;">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2" style="font-size: 12px;">No</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Iron Folic Acid</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>




<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Any H/O Chronic</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>

<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Hypertension</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>

<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Diabetes</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>

<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Complication in Pregnancy</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

</fieldset>


<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Risk</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Low Risk</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">High Risk</label>
</div>

</fieldset>

<fieldset class="form-group">
	 <label for="exampleInputEmail1"  class="col-sm-5" style="font-size: 14px;">Referral</label>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">SC</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">PHC</label>
</div>

</fieldset>



  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to ANM</button>
    </div>
  </div>
    <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Submit to PHC (MO)</button>
    </div>
  </div>
</form>












      </div>
    </div>
  </div>
</div>
















  </div>
</div>
	
</div>



</body>
</html>