<?php

require_once "Classes/PHPExcel.php";
$tmpfname = "abc.xlsx";
$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $excelObj = $excelReader->load($tmpfname);
  //  $worksheet = $excelObj->getSheet(1);
  //  $worksheet2 = $excelObj->getSheet(2);

 $sheetNames = $excelObj->getSheetNames();


  foreach ($sheetNames as $key => $sheetValues) {
      
      if ($sheetValues == 'Scheduling Tracker') {
           $s_t =  $key;
          echo $s_t;
         }
       

}
 ?>