<?php

require_once "Classes/PHPExcel.php";


$tmpfname = "read_from_it.xlsx";
$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $phpExcel = $excelReader->load($tmpfname);
$worksheet1 = $phpExcel->getSheet(0);

  $lastRow = $worksheet1->getHighestRow();
 $phpExcel->setActiveSheetIndex(0);



$phpExcel->getActiveSheet()->setCellValue( 'A1', 'hello');
$phpExcel->getActiveSheet()->setCellValue( 'A2', 'ok');





   

$writer = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");

// Save the spreadsheet

$writer->save('read_from_it.xlsx');

$file = fopen("read_from_it.xlsx","r");
//some code to be executed
fclose($file);

echo "<script>alert('Data has been added to file for reading!')</script>";
//echo "<script>window.open('index.php','_self')</script>";


?>