-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2018 at 08:49 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sxm`
--

-- --------------------------------------------------------

--
-- Table structure for table `schedule_tracking`
--

CREATE TABLE `schedule_tracking` (
  `ddate` varchar(256) DEFAULT NULL,
  `fa_code` varchar(256) DEFAULT NULL,
  `site_id` varchar(256) NOT NULL,
  `lat` varchar(256) NOT NULL,
  `longitude` varchar(256) NOT NULL,
  `market` varchar(256) NOT NULL,
  `submarket` varchar(256) NOT NULL,
  `wcs_wll` varchar(256) NOT NULL,
  `project` varchar(256) NOT NULL,
  `drive_type` varchar(256) NOT NULL,
  `comments` varchar(256) NOT NULL,
  `r360_tt_no` varchar(256) NOT NULL,
  `dr` varchar(256) NOT NULL,
  `rsl_fcc` varchar(256) NOT NULL,
  `site_readiness` varchar(256) NOT NULL,
  `site_status` varchar(256) NOT NULL,
  `iteration_number` varchar(256) NOT NULL,
  `remarks` varchar(256) NOT NULL,
  `additional_comments` varchar(256) NOT NULL,
  `error_code` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule_tracking`
--

INSERT INTO `schedule_tracking` (`ddate`, `fa_code`, `site_id`, `lat`, `longitude`, `market`, `submarket`, `wcs_wll`, `project`, `drive_type`, `comments`, `r360_tt_no`, `dr`, `rsl_fcc`, `site_readiness`, `site_status`, `iteration_number`, `remarks`, `additional_comments`, `error_code`) VALUES
('43185', '10039618', 'ALL01154', '34.16125', '-88.037917', 'Gulf States', 'Birmingham', '4', 'one', 'love', 'ANSB', '', 'Available', 'Available', '', '', 'Current Iteration No', '', '', ''),
('43185', '10139077', 'ALL03870', '31.255', '-85.3843', 'Gulf States', 'Montgomery', 'hello', '12', 'pride', 'KQs', '', 'Available', 'Available', '', '', 'Current Iteration No', '', '', ''),
('43185', '10078887', 'ALL05016', '30.50958857', '-87.36183763', 'Gulf States', 'Mobile', 'Nanan', '123', '', 'NKSBD', '', 'Available', 'Available', '', '', 'Current Iteration No', '', '', ''),
('43185', '10549855', 'MSL01294', '33.77425', '-89.826297', 'Gulf States', 'Jackson MS', 'random', '', '', '', '', 'Available', 'Available', '', '', 'Current Iteration No', '', '', ''),
('', 'dil', '', '', '', '', '', 'hello', 'from', '', '', '', '', '', '', '', '', '', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
