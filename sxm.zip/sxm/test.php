<?php

require_once "Classes/PHPExcel.php";
$tmpfname = "SMX_read.xlsx";
$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $excelObj = $excelReader->load($tmpfname);
  //  $worksheet = $excelObj->getSheet(1);
  //  $worksheet2 = $excelObj->getSheet(2);

 $sheetNames = $excelObj->getSheetNames();

 $con= mysqli_connect("localhost","root","","sxm");

if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}


 /*  foreach ($sheetNames as $key => $sheetValues) {
      
      if ($sheetValues == 'Scheduling Tracker') {
           $s_t =  $key;
          
         }
       
   } */

$worksheet1 = $excelObj->getSheet(0);

// $value = $worksheet1->getCell('A'.'3')->getValue();
  $lastRow = $worksheet1->getHighestRow();



for ($i=3; $i <= $lastRow ; $i++) { 
	$ddate[] = $worksheet1->getCell('A'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$fa_code[] = $worksheet1->getCell('B'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$site_id[] = $worksheet1->getCell('C'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$lat[] = $worksheet1->getCell('D'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$longitude[] = $worksheet1->getCell('E'.$i)->getValue();
}


for ($i=3; $i <= $lastRow ; $i++) { 
	$market[] = $worksheet1->getCell('F'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$submarket[] = $worksheet1->getCell('G'.$i)->getValue();
}
for ($i=3; $i <= $lastRow ; $i++) { 
	$wcs_wll[] = $worksheet1->getCell('H'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$project[] = $worksheet1->getCell('I'.$i)->getValue();
}
for ($i=3; $i <= $lastRow ; $i++) { 
	$drive_type[] = $worksheet1->getCell('J'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$comments[] = $worksheet1->getCell('K'.$i)->getValue();
}


for ($i=3; $i <= $lastRow ; $i++) { 
	$r360_tt_no[] = $worksheet1->getCell('L'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$dr[] = $worksheet1->getCell('M'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$rsl_fcc[] = $worksheet1->getCell('N'.$i)->getValue();
}


for ($i=3; $i <= $lastRow ; $i++) { 
	$site_readiness[] = $worksheet1->getCell('O'.$i)->getValue();
}


for ($i=3; $i <= $lastRow ; $i++) { 
	$site_status[] = $worksheet1->getCell('P'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$iteration_number[] = $worksheet1->getCell('Q'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$remarks[] = $worksheet1->getCell('R'.$i)->getValue();
}
for ($i=3; $i <= $lastRow ; $i++) { 
	$additional_comments[] = $worksheet1->getCell('S'.$i)->getValue();
}

for ($i=3; $i <= $lastRow ; $i++) { 
	$error_code[] = $worksheet1->getCell('T'.$i)->getValue();
}










for ($j=0; $j <= $lastRow - 3 ; $j++) { 

$insert_data="	INSERT INTO schedule_tracking(ddate, fa_code, site_id, lat, longitude, market, submarket, wcs_wll, project, drive_type, comments, r360_tt_no, dr, rsl_fcc, site_readiness, site_status, iteration_number, remarks, additional_comments, error_code) VALUES 
('$ddate[$j]', '$fa_code[$j]', '$site_id[$j]', '$lat[$j]', '$longitude[$j]', '$market[$j]', '$submarket[$j]', '$wcs_wll[$j]', '$project[$j]','$drive_type[$j]', '$comments[$j]', '$r360_tt_no[$j]', '$dr[$j]', '$rsl_fcc[$j]', '$site_readiness[$j]', '$site_status[$j]', '$iteration_number[$j]', '$remarks[$j]', '$additional_comments[$j]', '$error_code[$j]')";
mysqli_query($con, $insert_data);

   


}

echo "<script>alert('Data has been added!')</script>";
?>