<?php

require_once "Classes/PHPExcel.php";


$tmpfname = "SMX.xlsx";
$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $phpExcel = $excelReader->load($tmpfname);
$worksheet1 = $phpExcel->getSheet(0);

  $lastRow = $worksheet1->getHighestRow();
 $phpExcel->setActiveSheetIndex(0);



$con= mysqli_connect("localhost","root","","sxm");

if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}
   

$st = "SELECT * from schedule_tracking  ;";

$run_st = mysqli_query($con, $st);

$i = 0;
while ($row_st = mysqli_fetch_array($run_st))
{

 $j = $i+3;  
    $fa_code = $row_st['fa_code'];
    
$wcs_wll = $row_st['wcs_wll'];
$project = $row_st['project'];
$drive_type = $row_st['drive_type'];
$comments = $row_st['comments'];
$r360_tt_no = $row_st['r360_tt_no'];

$site_readiness = $row_st['site_readiness'];
$site_status = $row_st['site_status'];
$iteration_number = $row_st['iteration_number'];
$remarks = $row_st['remarks'];

$additional_comments = $row_st['additional_comments'];



$temp_h = "H".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_h, $wcs_wll);



$temp_i = "I".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_i, $project);

$temp_j = "J".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_j, $drive_type);


$temp_k = "K".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_k, $comments);

$temp_l = "L".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_l, $r360_tt_no);


$temp_o = "O".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_o, $site_readiness);


$temp_p = "P".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_p, $site_status);



$temp_s = "S".$j;

$phpExcel->getActiveSheet()->setCellValue( $temp_p, $additional_comments);


$i++;

}





















   

$writer = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");

// Save the spreadsheet

$writer->save('SMX.xlsx');

$file = fopen("SMX.xlsx","r");
//some code to be executed
fclose($file);

echo "<script>alert('Data has been added to file!')</script>";
echo "<script>window.open('test.php','_self')</script>";


?>