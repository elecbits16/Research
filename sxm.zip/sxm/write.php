<?php

require_once "Classes/PHPExcel.php";


$tmpfname = "SMX_read.xlsx";
$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $phpExcel = $excelReader->load($tmpfname);
$worksheet1 = $phpExcel->getSheet(0);

  $lastRow = $worksheet1->getHighestRow();

echo $lastRow;

$phpExcel->setActiveSheetIndex(0);
$phpExcel->getActiveSheet()->setCellValue('H4', 'Success');
   

$writer = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");

// Save the spreadsheet

$writer->save('SMX_write.xlsx');

$file = fopen("SMX_write.xlsx","r");
//some code to be executed
fclose($file);


?>