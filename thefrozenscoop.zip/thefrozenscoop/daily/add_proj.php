<!DOCTYPE html>
<html>
<head>
<?php

include("../functions/functions.php");

?>

	<title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1" /> 
  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
  
</head>
<style type="text/css">
  .btn{
    font-size: 14px;
  }
</style>
<body>

<div  class="container">


<br>
<blockquote class="blockquote" style=" border-style: solid; border-radius: 10px; border-color: #f7f7f7 ; font-size: 20px;  padding: 10px 10px 10px 10px;" >
 <img src="../symbol2.png " height="auto" width="200"> 
</blockquote>

<blockquote class="blockquote" style=" border-style: solid; border-radius: 10px; border-color: #f7f7f7 ; font-size: 20px;  padding: 10px 10px 10px 10px;" >
  <p class="mb-0" >Add Subscription</p>
</blockquote>


<div class="col-lg-12">
  <form method="post" action="">
           <div class="form-group row">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Subscription ID</label>
      <div class="col-sm-10" >
        <input type="text" style="font-size: 14px;" class="form-control" id="inputEmail3" name="s_id" placeholder="Subscription ID" required>
      </div>
    </div>
        <div class="form-group row">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
      <div class="col-sm-10" >
        <input type="text" style="font-size: 14px;" class="form-control" id="inputEmail3" name="s_name" placeholder="Name">
      </div>
    </div>
    <div class="form-group row">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
      <div class="col-sm-10" >
        <input type="email" style="font-size: 14px;" class="form-control" id="inputEmail3" name="s_email" placeholder="email">
      </div>
    </div>
    <div class="form-group row">
      <label for="inputPassword3"  class="col-sm-2 col-form-label">Contact</label>
      <div class="col-sm-10">
        <input type="number" style="font-size: 14px;" class="form-control" id="inputPassword3" name="s_contact" placeholder="contact" required>
      </div>
    </div>
            <div class="form-group row">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Subscription</label>
      <div class="col-sm-10" >
         <textarea class="form-control" id="exampleTextarea" style="font-size: 14px;" rows="3" name="subs" placeholder="Description" required></textarea>
      </div>
    </div>

       <div class="form-group row">
      <label for="inputPassword3"  class="col-sm-2 col-form-label">Address</label>
       <div class="col-sm-10" >
         <textarea class="form-control" id="exampleTextarea" style="font-size: 14px;" rows="3" name="address" placeholder="Address" required></textarea>
      </div>
    </div>


      <div class="form-group row">
      <label for="inputPassword3"  class="col-sm-2 col-form-label">Area</label>
       <div class="col-sm-10">
        <input type="text" style="font-size: 14px;" class="form-control" id="inputPassword3" name="area" placeholder="Area" required>
      </div>
    </div>

        <div class="form-group row">
      <label for="inputPassword3"  class="col-sm-2 col-form-label">Start Date</label>
      <div class="col-sm-10">
        <input type="date" style="font-size: 14px;" name="s_date"  required>
      </div>
    </div>







 
    <div class="form-group row">
      <div class="offset-sm-2 col-sm-10">
        <button type="submit" name="add_p" class="btn btn-primary">Add Projects</button>
      </div>
    </div>
  </form>
</div>     
   


<br>
<hr>








  

    </div>





</body>
</html>


<?php

if (isset($_POST['add_p'])) {




 $s_id = $_POST['s_id']; 
$s_name = $_POST['s_name'];
$s_email = $_POST['s_email'];

$subs = $_POST['subs'];
$s_contact = $_POST['s_contact'];

$address = $_POST['address'];
$area = $_POST['area'];
$s_date = $_POST['s_date'];





$emp_count = "SELECT * from subslist where sub_id = '$s_id'";
$row_count = mysqli_query($con, $emp_count);

$count_upsert_query = mysqli_num_rows($row_count);

if ($count_upsert_query == 0)
{

$insert_emp = "INSERT INTO subslist (sub_id, name, email, contact, subscription, address, area, Start_Date) VALUES ('$s_id','$s_name','$s_email','$s_contact','$subs','$address','$area','$s_date') " ;


 echo "Error: " . $insert_emp . "<br>" . mysqli_error($con);

if (mysqli_query($con, $insert_emp)) {
   echo "<script>alert('Subscription Added')</script>";  
   echo "<script>window.open('index.php','_self')</script>";

}





}



else
{

  echo "<script>alert('Subscription Already exist')</script>";  
   echo "<script>window.open('index.php','_self')</script>";

}





}






?>