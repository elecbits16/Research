-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2018 at 06:30 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `frozenscoop`
--

-- --------------------------------------------------------

--
-- Table structure for table `subslist`
--

CREATE TABLE `subslist` (
  `sub_id` varchar(256) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `contact` varchar(256) NOT NULL,
  `subscription` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `area` varchar(256) NOT NULL,
  `Start_date` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subslist`
--

INSERT INTO `subslist` (`sub_id`, `name`, `email`, `contact`, `subscription`, `address`, `area`, `Start_date`) VALUES
('s_id', 's_name', 's_email', 's_contact', 'subs', 'address', 'area', 's_date'),
('123456', '', '', '84737589473', '1 lt , 5 lt , 7 lt', 'TOWER 58, hello world', 'Amanora', '2018-01-23');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
