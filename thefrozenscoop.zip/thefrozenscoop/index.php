<!DOCTYPE html>

<html lang="en">
    <head>
      <meta charset="utf-8">
      <title>FrozenScoop | Ice cream parlor</title>
      <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

      <!-- Favicon ================== -->
      <!-- Standard -->
      <link rel="shortcut icon" href="logo.png">
      <!-- Retina iPad Touch Icon-->
      <link rel="apple-touch-icon" sizes="144x144" href="logo.png">
      <!-- Retina iPhone Touch Icon-->
      <link rel="apple-touch-icon" sizes="114x114" href="logo.png">
      <!-- Standard iPad Touch Icon-->
      <link rel="apple-touch-icon" sizes="72x72" href="logo.png">
      <!-- Standard iPhone Touch Icon-->
      <link rel="apple-touch-icon" sizes="57x57" href="logo.png">

      <!--  Resources style ================== -->
      <link href="css/theme-MariBlue.css" rel="stylesheet" type="text/css" media="all"/>
    </head>
    <body>
      <section class="animsition">

        <div id="leftSide">

          <div id="home" class="">

            <!-- Your logo -->
  			    <img src="symbol.png" alt="" style="position: absolute;
  top: 8%; left:10%;" width="auto" height="200" />

            <div class="h-content">
              <h1><br>The Frozen Scoop </h1>
              <p>Ice Cream is always an option.   <img src="wink.png" width="30" height="auto"></p>
              <img src="cream.png">
              
            </div>

            <ul class="social_icons">
              <li><a href="#"><i class="icon ion-social-facebook"></i></a></li>
             
            </ul>

            <div id="particles-js" class="gradient"></div>
            <div class="count-particles">
              <span class="js-count-particles"></span>
            </div>

          </div>

        </div>

        <div id="rightSide">

      <!--    <div class="project">
            <ul class="gallery project_navigation">
              <li class="item col-sm-6 col-xs-12">
                <figure>
                  Your picture 
                  <img src="img/pexels-photo-14075.jpeg" alt="This is my work" class="img-responsive" />
                  Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Music Player</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project1" class="view">VIEW</a>
                  </figcaption>
                </figure>
              </li>

              <li class="item col-sm-6 col-xs-12">
                <figure>
                  Your picture 
                  <img src="img/shells-massage-therapy-sand.jpg"  alt="This is my work" class="img-responsive" />
                  Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Sea Shells</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project2" class="view">VIEW</a>
                  </figcaption>
                </figure>
              </li>

              <li class="item col-sm-6 col-xs-12">
                <figure>
                  <!-- Your picture 
                  <img src="img/typing-vintage-technology-keyboard.jpg"  alt="This is my work" class="img-responsive" />
                  <!-- Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Typing</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project3" class="view">VIEW</a>
                  </figcaption>
                </figure>
              </li>

              <li class="item col-sm-6 col-xs-12">
                <figure>
                  <!-- Your picture 
                  <img src="img/hand-taking-photo-photography-vintage.jpg"  alt="This is my work" class="img-responsive" />
                  <!-- Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Camera</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project4" class="view">VIEW</a>
                  </figcaption>
                </figure>
              </li>

              <li class="item col-sm-6 col-xs-12">
                <figure>
                  <!-- Your picture
                  <img src="img/guitar.jpg"  alt="This is my work" class="img-responsive" />
                  <!-- Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Guitar</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project5" class="view">VIEW</a>
                  </figcaption>
                </figure>
              </li>

              <li class="item col-sm-6 col-xs-12">
                <figure>
                  <!-- Your picture 
                  <img src="img/food-plate-yellow-white.jpg"  alt="This is my work" class="img img-responsive" />
                  <!-- Picture's description below this one 
                  <figcaption class="caption">
                    <div class="photo-details">
                      <h4>Food</h4>
                      <span>By Code Rare</span>
                    </div>
                    <a href="#project6" class="view">VIEW</a>

                  </figcaption>
                </figure>
              </li>
            </ul>

            <ul class="project_info">
              <li id="project1">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>

              <li id="project2">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>

              <li id="project3">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>

              <li id="project4">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>

              <li id="project5">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>

              <li id="project6">
                <div class="project_content">
                  <h2>YOUR TITLE GOES HERE</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, amet, voluptatibus et omnis dolore illo saepe voluptatem qui quibusdam sunt corporis ut iure repellendus delectus voluptate explicabo temporibus quos eaque?
                  </p>
                </div>
              </li>
            </ul>
          </div> 

          <div id="subscribe">
            <h2>Stay tunned we're coming soon</h2>
            <div class="mb100" id="clock" data-date="2016/08/02 12:00:00"></div>

            <form action=""
            method="post">
              <input type="email" name="EMAIL" class="input-email" value="" placeholder="Email address *" required="">
              <button type="submit" name="sub" class="submit input-submit" >Subscribe</button>
              <div id="subscribe-result"></div>
            </form>
          </div> -->


     <!--  <div class="about">
            <h2>Get started fast with one of our unique, pre-built concepts.</h2>
            <p>
              Customers love our block-based approach to template building,
              it makes assembling beautiful pages fast and enjoyable, leaving
               more time to craft your perfect layout. love our block-based
              approach to template building, it makes assembling beautiful pages
              fast and enjoyable, leaving more time to craft your perfect layout.
            </p>

            <p>
              Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.
            </p>

            <div class="service row">
              <div class="feature col-sm-3 col-xs-3">
                <i class="ion-heart"></i>
                <h6>SIMPLE</h6>
              </div>

              <div class="feature col-sm-3 col-xs-3">
                <i class="ion-erlenmeyer-flask"></i>
                <h6>CREATIVE</h6>
              </div>

              <div class="feature col-sm-3 col-xs-3">
                <i class="ion-waterdrop"></i>
                <h6>SMOOTH</h6>
              </div>

              <div class="feature col-sm-3 col-xs-3">
                <i class="ion-code"></i>
                <h6>STABLE</h6>
              </div>
            </div>
          </div> 

          <div class="pricing">
            <div class="row">
              <div class="offers col-sm-8 col-xs-8">
                <ul class="col-sm-6 col-xs-6">
                  <li>Hosting</li>
                  <li>Web Security</li>
                  <li>Domain</li>
                </ul>

                <ul class="col-sm-6 col-xs-6">
                  <li>24/7 Support</li>
                  <li>Email Hosting</li>
                  <li>Premium DNS</li>
                </ul>
              </div>

              <div class="price col-sm-4 col-xs-4">
                <h5 class="rate">29</h5>
                <p><strong>Per Month</strong></p>
              </div>
            </div>
          </div> -->

          <div id="contact" class="row">
              <h2>Get in <strong>touch</strong>, we'd love to hear from you.</h2>
             
              <address class="row">
                <span class="col-sm-6 col-xs-12">
                  <i class="ion-location"></i>
                  Shop No -3, Urban Plaza
                  Tower - 58, Future Tower,
                  Amanora Township, Pune - 411028
                </span>
                <span class="col-sm-6 col-xs-12">
                  <i class="ion-ios-telephone"></i>
                  8860394267
                </span>
                <span class="col-sm-6 col-xs-12">
                  <i class="ion-email"></i>
                 frozenscoop100@gmail.com
                </span>
              </address>

              <form id="contact_form" class="row" method="post" action="php/mailer.php">
                <div class="col-sm-6 col-xs-12">
                  <input type="name" name="name" class="input-name" placeholder="Name">
                  <input type="email" name="email" class="input-email" placeholder="Email">
                </div>

                <div class="col-sm-6 col-xs-12">
                  <textarea name="message" class="input-message" placeholder="Message"></textarea>
                </div>

                <div class="col-sm-12 col-xs-12">
                  <button class="submit">Send</button>
                </div>

                <div id="form-messages" class="col-sm-12 col-xs-12">
                  <span class="success col-sm-12 col-xs-12"></span>
                  <span class="error col-sm-12 col-xs-12"></span>
                </div>
              </form>
          </div>

          <footer>
            <p class="uppercase">© Elecbits - Made With Love <i class="ion-heart"></i></p>
            <div class="drag">
              <i class="up ion-arrow-up-c"></i>
            </div>
          </footer>

        </div>
      </section>

      <script src="js/jquery-1.11.3.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/animsition.min.js"></script>
      <script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
      <script src="js/jquery.magnific-popup.min.js"></script>
      <script src="js/jquery.countdown.min.js"></script>
      <script src="js/twitterFetcher_min.js"></script>
      <script src="js/masonry.pkgd.min.js"></script>
      <script src="js/imagesloaded.pkgd.min.js"></script>
      <script src="js/jquery.flexslider-min.js"></script>
      <script src="js/photoswipe.min.js"></script>
      <script src="js/photoswipe-ui-default.min.js"></script>
      <script src="js/jqinstapics.min.js"></script>
      <script src="js/particles.min.js"></script>
      <script type="text/javascript">
        particlesJS("particles-js", {"particles":{"number":{"value":67,"density":{"enable":true,"value_area":800}},"color":{"value":"#ffffff"},"shape":{"type":"triangle","stroke":{"width":0,"color":"#000000"},"polygon":{"nb_sides":5},"image":{"src":"img/github.svg","width":100,"height":100}},"opacity":{"value":0.5,"random":false,"anim":{"enable":false,"speed":1,"opacity_min":0.1,"sync":false}},"size":{"value":12,"random":true,"anim":{"enable":false,"speed":40,"size_min":0.1,"sync":false}},"line_linked":{"enable":true,"distance":150,"color":"#ffffff","opacity":0.4,"width":1},"move":{"enable":true,"speed":6,"direction":"none","random":false,"straight":false,"out_mode":"out","bounce":false,"attract":{"enable":false,"rotateX":600,"rotateY":1200}}},"interactivity":{"detect_on":"canvas","events":{"onhover":{"enable":false,"mode":"repulse"},"onclick":{"enable":false,"mode":"push"},"resize":true},"modes":{"grab":{"distance":400,"line_linked":{"opacity":1}},"bubble":{"distance":400,"size":40,"duration":2,"opacity":8,"speed":3},"repulse":{"distance":200,"duration":0.4},"push":{"particles_nb":4},"remove":{"particles_nb":2}}},"retina_detect":true});var count_particles, stats, update; stats = new Stats; stats.setMode(0); stats.domElement.style.position = 'absolute'; stats.domElement.style.left = '0px'; stats.domElement.style.top = '0px'; document.body.appendChild(stats.domElement); count_particles = document.querySelector('.js-count-particles'); update = function() { stats.begin(); stats.end(); if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) { count_particles.innerText = window.pJSDom[0].pJS.particles.array.length; } requestAnimationFrame(update); }; requestAnimationFrame(update);;
      </script>
      <script src="js/script.js"></script>
  </body>
</html>


<?php
   if (isset($_POST['sub']))

    {

      $email = $_POST['email'];
     
     
      $msg = "$email";

       $from= "from: Subscribe@thefrozenscoop.in";

       if(filter_var($email, FILTER_VALIDATE_EMAIL)){

if( mail("saurav.rav67@gmail.com", "Newsletter", $msg, $from) && mail("thefrozenscoop100@gmail.com", "Newsletter", $msg, $from) &&mail($email, "We appreciate your concern","Thank you for subscribing to our NEWSLETTER." , $from) ) 
      {  
           echo "<script>alert('Thank you for subscribing to our Newsletter.')</script>";  
      }  

}

   }


?>